function onFieldChange()
{
    //alert('Now a shipment would be created');
    var pick1 = custpage_sublist_id.selected;
    alert(pick1);
}